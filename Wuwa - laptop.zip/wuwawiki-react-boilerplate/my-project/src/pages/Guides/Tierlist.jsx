import React from 'react'

const Tierlist = () => {
  return (
    <div>
      
    </div>
  )
}

export default Tierlist
