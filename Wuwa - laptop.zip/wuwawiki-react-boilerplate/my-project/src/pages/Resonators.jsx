import React from 'react'
import data from "../Resonators.json";

const Resonators = () => {
  return (
    <div>
      
    </div>
  )
}

export default Resonators
