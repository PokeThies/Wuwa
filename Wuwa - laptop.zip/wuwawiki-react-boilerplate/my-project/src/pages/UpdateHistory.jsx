import React from 'react'

const UpdateHistory = () => {
  return (
    <div>
      
    </div>
  )
}

export default UpdateHistory
