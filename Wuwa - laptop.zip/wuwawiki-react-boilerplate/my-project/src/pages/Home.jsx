import React, { useState } from "react";
import { Link } from "react-router-dom";
import Cammellya_Drip from "/imgs/Camellya_drip.jpg";
import Wuthering_Waves_Tier_List from "/imgs/Wuthering_Waves_Tier_List.jpg";
import Sonance_Casket_Farming_Guide from "/imgs/Sonance_Casket_Farming_Guide.jpg";
import Redeem_Code_Free_Astrite from "/imgs/Redeem_Code_Free_Astrite.jpg";
import Echoes_Farming_Guide from "/imgs/Echoes_Farming_Guide.jpg";
import Camellya_Material_Nova_Farming_Guide from "/imgs/Camellya_Material_Nova_Farming_Guide.jpg";
import Ascension_Materials_Farming_Guide from "/imgs/Ascension_Materials_Farming_Guide.jpg";
import data from "../Resonators.json";

const Elements = [
  { src: "/imgs/Aero.png", alt: "Aero Element" },
  { src: "/imgs/Spectro.png", alt: "Spectro Element" },
  { src: "/imgs/Electro.png", alt: "Electro Element" },
  { src: "/imgs/Fusion.png", alt: "Fusion Element" },
  { src: "/imgs/Glacio.png", alt: "Glacio Element" },
  { src: "/imgs/Havoc.png", alt: "Havoc Element" },
];

const Weapons = [
  { src: "/imgs/Heavyblade.png", alt: "Heavyblade" },
  { src: "/imgs/Auralator.png", alt: "Auralator" },
  { src: "/imgs/Pistol.png", alt: "Pistol" },
  { src: "/imgs/Sword.png", alt: "Sword" },
  { src: "/imgs/Gauntlet.png", alt: "Gauntelt" },
];

const weapomTypes = {
  null: Symbol("null"),
  pistol: Symbol("pistol"),
  sword: Symbol("sword"),
  auralator: Symbol("Auralator"),
  heavyblade: Symbol("Heavyblade"),
  guantlet: Symbol("Guantelt"),
};
let filter = weapomTypes.null;

const Home = () => {
  return (
    <>
      {data.Resonators.filter((entry) => {
        return entry.Weapon === "Pistol" || entry.build === "Aalto build";
      }).map((current) => {
        console.log(current.src); //map ud de forskellige karaktere
      })}

      <div className="bg-gradient-to-b from-slate-950 via-slate-950 to-zinc-950 min-h-screen md:p-4 sm:px-4 px-4">
        {/* Responsive Content Container */}
        <div className="container border border-gray-600 bg-gradient-to-b from-slate-950 via-slate-950 to-zinc-950 mx-auto px-4 py-6 mt-2 rounded-lg shadow-lg max-w-screen-sm md:max-w-screen-lg sm:max-w-screen-md  lg:max-w-screen-lg xl:max-w-screen-xl">
          {/* Header Section */}
          <section className="text-2xl text-center text-white font-sans font-semibold">
            <p>Wuthering Waves Characters</p>
          </section>

          {/* Last Updated Section */}

          <section className="text-white pt-12 pb-4 text-sm font-sans px-2">
            <p className="font-semibold">
              <span className="font-bold">Last updated:</span> November 29,
              2024, 12:07
            </p>
          </section>

          {/* Latest Characters Section */}
          <section className="mt-6 text-white">
            <div className="relative flex items-center">
              <hr className="flex-grow border-gray-300" />
              <span className="mx-2 text-sm text-gray-300 font-sans font-semibold">
                Latest Characters
              </span>
              <hr className="flex-grow border-gray-400" />
            </div>
          </section>

          {/* Responsive Card */}
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:px-10 gap-6">
            {/* Card */}
            <div className="bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300">
              {/* Image with Hover Effect */}
              <div className="relative group overflow-hidden">
                {/* Image Link */}
                <Link to="/Camellya" className="block">
                  {/* Image */}
                  <img
                    src={Cammellya_Drip}
                    alt="Camellya drip marketing"
                    className="w-full h-auto object-cover transition-transform duration-1000 transform group-hover:scale-105"
                  />
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Link>
              </div>

              {/* Card Content */}
              <div className="p-4 bg-black bg-opacity-90 text-white">
                <h3 className="text-lg font-serif font-bold bg-gradient-to-t from-red-500 to-white bg-clip-text text-transparent">
                  Camellya
                </h3>
                <p className="text-sm text-gray-400">
                  Click to explore Camellya's builds, weapons, and more.
                </p>
              </div>
            </div>
          </div>

          {/* Change Log Divider */}
          <section className="mt-10 text-white">
            <div className="relative flex items-center">
              <hr className="flex-grow border-gray-300" />
              <span className="mx-2 text-sm text-gray-300 font-sans font-semibold">
                Change log
              </span>
              <hr className="flex-grow border-gray-400" />
            </div>
          </section>

          {/* Updated Characters Section */}
          <section className="text-white pt-6 text-sm font-serif font-semibold">
            <Link to="/Camellya">
              <p>
                Updated complete{" "}
                <span className="text-red-500 font-bold hover:cursor-pointer hover:text-red-600 underline">
                  Camellya Build
                </span>
                <span className="font-bold">.</span>
              </p>
            </Link>
          </section>

          {/* Character Guides Divider */}
          <section className="mt-6 text-white">
            <div className="relative flex items-center">
              <hr className="flex-grow border-gray-300" />
              <span className="mx-2 text-sm text-gray-300 font-sans font-semibold">
                Character Guides
              </span>
              <hr className="flex-grow border-gray-400" />
            </div>
          </section>

          {/* Character Details Section */}
          <section className="text-white pt-6 font-sans">
            <p className="text-gray-300">
              In the latest release, there are currently 24 characters in
              Wuthering Waves (update in progress). Click on character icons for
              more details about each character, including their builds,
              weapons, and background information.
              <br /> <br />
              <span className="font-bold text-white">Elements</span>
              <br />
              <br />
              Wuthering Waves features six elements: Aero, Electro, Fusion,
              Glacio, Havoc, and Spectro.
            </p>

            {/* Responsive Cards Section */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 px-4">
              {/* Card 1 */}
              <Link
                to="/Ascension"
                className="flex flex-col sm:flex-row items-center bg-zinc-800 rounded-lg shadow-md overflow-hidden transition-all duration-300"
              >
                {/* Image */}
                <figure className="relative group overflow-hidden flex-shrink-0 w-full sm:w-2/3">
                  <img
                    src={Ascension_Materials_Farming_Guide}
                    alt="Ascension Materials Routes & Farming Guide"
                    className="w-full xl:h-52 lg:h-52 md:h-52 h-40 object-cover transition-transform duration-500 transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </figure>
                {/* Text Content */}
                <div className="p-4 text-white sm:pl-6">
                  <h3 className="text-lg font-semibold mb-2 hover:cursor-pointer hover:text-blue-500">
                    Ascension Materials Routes & Farming Guide
                  </h3>
                </div>
              </Link>

              {/* Card 2 */}
              <Link
                to="/Sonacecasket"
                className="flex flex-col sm:flex-row items-center bg-zinc-800 rounded-lg shadow-md overflow-hidden transition-all duration-300"
              >
                {/* Image */}
                <figure className="relative group overflow-hidden flex-shrink-0 w-full sm:w-2/3">
                  <img
                    src={Sonance_Casket_Farming_Guide}
                    alt="Sonance Casket Routes & Locations"
                    className="w-full xl:h-52 lg:h-52 md:h-52 h-40 object-cover transition-transform duration-500 transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </figure>
                {/* Text Content */}
                <div className="p-4 text-white sm:pl-6">
                  <h3 className="text-lg font-semibold mb-2 hover:cursor-pointer hover:text-blue-500">
                    Sonance Casket Routes & Locations
                  </h3>
                </div>
              </Link>

              {/* Card 3 */}
              <Link
                to="/Redeemcode"
                className="flex flex-col sm:flex-row items-center bg-zinc-800 rounded-lg shadow-md overflow-hidden transition-all duration-300"
              >
                {/* Image */}
                <figure className="relative group overflow-hidden flex-shrink-0 w-full sm:w-2/3">
                  <img
                    src={Redeem_Code_Free_Astrite}
                    alt="Redeem Code"
                    className="w-full xl:h-52 lg:h-52 md:h-52 h-40 object-cover transition-transform duration-500 transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </figure>
                {/* Text Content */}
                <div className="p-4 text-white sm:pl-6">
                  <h3 className="text-lg font-semibold mb-2 hover:cursor-pointer hover:text-blue-500">
                    Redeem Code
                  </h3>
                </div>
              </Link>

              {/* Card 4 */}
              <Link
                to="/Novaroutes"
                className="flex flex-col sm:flex-row items-center bg-zinc-800 rounded-lg shadow-md overflow-hidden transition-all duration-300"
              >
                {/* Image */}
                <figure className="relative group overflow-hidden flex-shrink-0 w-full sm:w-2/3">
                  <img
                    src={Camellya_Material_Nova_Farming_Guide}
                    alt="Camellya Material: Nova Routes & Best Farming Guide"
                    className="w-full xl:h-52 lg:h-52 md:h-52 h-40 object-cover transition-transform duration-500 transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </figure>
                {/* Text Content */}
                <div className="p-4 text-white sm:pl-6">
                  <h3 className="text-lg font-semibold mb-2 hover:cursor-pointer hover:text-blue-500">
                    Camellya Material: Nova Routes
                  </h3>
                </div>
              </Link>

              {/* Card 5 */}
              <Link
                to="/Echoroutes"
                className="flex flex-col sm:flex-row items-center bg-zinc-800 rounded-lg shadow-md overflow-hidden transition-all duration-300"
              >
                {/* Image */}
                <figure className="relative group overflow-hidden flex-shrink-0 w-full sm:w-2/3">
                  <img
                    src={Echoes_Farming_Guide}
                    alt="Echo Farming Routes & Location"
                    className="w-full xl:h-52 lg:h-52 md:h-52 h-40 object-cover transition-transform duration-500 transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </figure>
                {/* Text Content */}
                <div className="p-4 text-white sm:pl-6">
                  <h3 className="text-lg font-semibold mb-2 hover:cursor-pointer hover:text-blue-500">
                    Echo Farming Routes & Location
                  </h3>
                </div>
              </Link>

              {/* Card 6 */}
              <Link
                to="/Tierlist"
                className="flex flex-col sm:flex-row items-center bg-zinc-800 rounded-lg shadow-md overflow-hidden transition-all duration-300"
              >
                {/* Image */}
                <figure className="relative group overflow-hidden flex-shrink-0 w-full sm:w-2/3">
                  <img
                    src={Wuthering_Waves_Tier_List}
                    alt="Wuthering Waves Tier List"
                    className="w-full xl:h-52 lg:h-52 md:h-52 h-40 object-cover transition-transform duration-500 transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </figure>
                {/* Text Content */}
                <div className="p-4 text-white sm:pl-6">
                  <h3 className="text-lg font-semibold mb-2 hover:cursor-pointer hover:text-blue-500">
                    Wuthering Waves Tier List
                  </h3>
                </div>
              </Link>
            </div>
          </section>

          {/* Characters List Divider */}
          <section className="mt-10 text-white mb-10">
            <div className="relative flex items-center">
              <hr className="flex-grow border-gray-300" />
              <span className="mx-2 text-sm text-gray-300 font-sans font-semibold">
                Characters List
              </span>
              <hr className="flex-grow border-gray-400" />
            </div>

            {/* Sort By */}
            <div className="flex flex-col items-center justify-center mt-10">
              {/* Elements Mapping */}
              <div className="grid grid-cols-6 sm:grid-cols-6 md:grid-cols-6 gap-4">
                {Elements &&
                  Elements.map((e, index) => (
                    <img
                      className="flex items-center justify-center w-14 h-14 xl:h-20 lg:h-20 md:h-16 sm:h-16 xl:w-20 lg:w-20 md:w-16 sm:w-16 bg-zinc-800 rounded-lg p-2 hover:scale-105 border-blue-600 hover:border transform transition-all duration-300 ease-in-out"
                      src={e.src}
                      alt={e.alt}
                    />
                  ))}
              </div>

              {/* Weapons Mapping */}
              <div className="grid grid-cols-5 sm:grid-cols-5 md:grid-cols-5 gap-4 mt-6">
                {Weapons &&
                  Weapons.map((w, index) => (
                    <img
                      className="flex items-center justify-center w-16 h-16 xl:h-20 lg:h-20 md:h-16 sm:h-16 xl:w-20 lg:w-20 md:w-16 sm:w-16 bg-zinc-800 rounded-lg p-2 hover:scale-105 border-blue-600 hover:border transform transition-all duration-300  ease-in-out"
                      src={w.src}
                      alt={w.alt}
                    />
                  ))}
              </div>

              <div className="mt-8">
                {/* 5-Star Resonators */}
                <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4 mb-8">
                  {data.Resonators &&
                    data.Resonators.filter((r) => r.Star === "5")
                      .filter((r) => {
                        switch (filter) {
                          case weapomTypes.null:
                            return true;
                          case weapomTypes.pistol:
                            return r.Weapon === "Pistol";
                          case weapomTypes.sword:
                            return r.Weapon === "Sword";
                          case weapomTypes.heavyblade:
                            return r.Weapon === "Heavyblade";
                          case weapomTypes.auralator:
                            return r.Weapon === "Auralator";
                          case weapomTypes.guantlet:
                            return r.Weapon === "Guantelt";
                          default:
                            return true;
                        }
                      })
                      .map((r, index) => {
                        // Background style for 5-star Resonators
                        const backgroundClass =
                          "bg-gradient-to-br from-orange-100 via-yellow-500 to-yellow-800 saturate-100";

                        return (
                          <figure
                            key={index}
                            className={`${backgroundClass} saturate-100 p-2 w-full max-w-[12rem] rounded-2xl hover:scale-105 outline-none hover:outline-blue-600 transform duration-300 ease-in-out flex flex-col items-center`}
                          >
                            <img
                              className="mb-4 w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 lg:w-28 lg:h-28 xl:w-32 xl:h-32"
                              src={r.src}
                              alt={r.alt}
                            />
                            <figcaption className="font-bold text-center text-sm sm:text-base md:text-lg text-nowrap">
                              {r.build || r.alt}
                            </figcaption>
                          </figure>
                        );
                      })}
                </div>

                {/* 4-Star Resonators */}
                <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4">
                  {data.Resonators &&
                    data.Resonators.filter((r) => r.Star === "4")
                      .filter((r) => {
                        switch (filter) {
                          case weapomTypes.null:
                            return true;
                          case weapomTypes.pistol:
                            return r.Weapon === "Pistol";
                          case weapomTypes.sword:
                            return r.Weapon === "Sword";
                          case weapomTypes.heavyblade:
                            return r.Weapon === "Heavyblade";
                          case weapomTypes.auralator:
                            return r.Weapon === "Auralator";
                          case weapomTypes.guantlet:
                            return r.Weapon === "Guantelt";
                          default:
                            return true;
                        }
                      })
                      .map((r, index) => {
                        // Background style for 4-star Resonators
                        const backgroundClass =
                          "bg-gradient-to-br from-violet-100 via-purple-800 to-purple-950";

                        return (
                          <figure
                            key={index}
                            className={`${backgroundClass} saturate-100 p-2 w-full max-w-[12rem] rounded-2xl hover:scale-105 outline-none hover:outline-blue-600 transform duration-300 ease-in-out flex flex-col items-center`}
                          >
                            <img
                              className="mb-4 w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 lg:w-28 lg:h-28 xl:w-32 xl:h-32"
                              src={r.src}
                              alt={r.alt}
                            />
                            <figcaption className="font-bold text-center text-sm sm:text-base md:text-lg text-nowrap">
                              {r.build || r.alt}
                            </figcaption>
                          </figure>
                        );
                      })}
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </>
  );
};

export default Home;
