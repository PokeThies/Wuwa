import { RouterProvider, createBrowserRouter } from "react-router-dom";
import About from "./pages/About";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import PageNotFound from "./pages/PageNotFound";
import Layout from "./layout/Layout";
import AdminLayout from "./layout/Admin/AdminLayout";
import AdminHome from "./pages/Admin/AdminHome";
import "./App.css";
import Resonators from "./pages/Resonators";
import Echoes from "./pages/Echoes";
import Weapons from "./pages/Weapons";
import Guide from "./pages/Guide";
import UpdateHistory from "./pages/UpdateHistory";
import Camellya from "./pages/Resonators/Camellya";
import Novaroutes from "./pages/Guides/Novaroutes";
import Ascention from "./pages/Guides/Ascension"
import Echoroutes from "./pages/Guides/Echoroutes"
import Redeemcode from "./pages/Guides/Redeemcode"
import Sonacecasket from "./pages/Guides/Sonacecasket"
import Tierlist from "./pages/Guides/Tierlist"


function App() {
  const router = createBrowserRouter([
    {
      element: <Layout />,
      errorElement: <PageNotFound />,
      children: [
        /* ------- Public ------- */
        { path: "/", element: <Home /> },
        { path: "about", element: <About /> },
        { path: "contact", element: <Contact /> },
        { path: "resonators", element: <Resonators /> },
        { path: "echoes", element: <Echoes /> },
        { path: "weapons", element: <Weapons/> },
        { path: "contact", element: <Contact /> },
        { path: "guide", element: <Guide /> },
        { path: "updatehistory", element: <UpdateHistory /> },
        { path: "camellya", element: <Camellya /> },
        { path: "novaroutes", element: <Novaroutes /> },
        { path: "ascension", element: <Ascention /> },
        { path: "echoroutes", element: <Echoroutes /> },
        { path: "redeemcode", element: <Redeemcode /> },
        { path: "sonacecasket", element: <Sonacecasket /> },
        { path: "tierlist", element: <Tierlist /> },
      ],
    },
     {
      element: <AdminLayout />,
      errorElement: <PageNotFound />,
      children: [
        /* ------- Admin ------- */
        { path: "/", element: <AdminHome /> },
      ],
    },
  ]);

  return (
    <>
      <section>
        <RouterProvider router={router} />
      </section>
    </>
  );
}

export default App;
