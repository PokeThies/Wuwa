import React, { useState } from "react";
import { Link } from "react-router-dom";
import Wuwa_logo from "/imgs/Wuwa_logo.png";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-gradient-to-r from-gray-900 via-slate-950 to-zinc-950 text-gray-300 font-mono font-semibold border-b border-gray-600">
      <menu>
        <div className="max-w-screen-xl mx-auto px-6 xl:px-4 lg:px-12 md:px-8 flex justify-between items-center py-4 border-b border-gray-600">
          {/* Logo / Home Link */}
          <Link to="/" className="text-2xl font-bold hover:text-blue-300">
            <figure className="w-40 mt-2">
              <img src={Wuwa_logo} alt="Wuthering Waves logo" />
            </figure>
          </Link>

          {/* Desktop Menu */}
          <li className="hidden md:flex space-x-6 text-lg">
            <Link to="/resonators" className="hover:text-gray-400">
              Resonators
            </Link>
            <Link to="/echoes" className="hover:text-gray-400">
              Echoes
            </Link>
            <Link to="/weapons" className="hover:text-gray-400">
              Weapons
            </Link>
            <Link to="/guide" className="hover:text-gray-400">
              Guide
            </Link>
            <Link to="/updatehistory" className="hover:text-gray-400">
              Update History
            </Link>
          </li>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden focus:outline-none"
            aria-label="Toggle Menu"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              {isOpen ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h16m-7 6h7"
                />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu with Animation */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-1000 ease-in-out ${
            isOpen ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <li className="bg-gradient-to-r from-gray-900 via-slate-950 to-zinc-950space-y-2 p-4  text-lg text-end">
            <Link
              to="/resonators"
              onClick={() => setIsOpen(false)}
              className="block hover:text-gray-400"
            >
              Resonators
            </Link>
            <Link
              to="/echoes"
              onClick={() => setIsOpen(false)}
              className="block hover:text-gray-400"
            >
              Echoes
            </Link>
            <Link
              to="/weapons"
              onClick={() => setIsOpen(false)}
              className="block hover:text-gray-400"
            >
              Weapons
            </Link>
            <Link
              to="/guide"
              onClick={() => setIsOpen(false)}
              className="block hover:text-gray-400"
            >
              Guide
            </Link>
            <Link
              to="/updatehistory"
              onClick={() => setIsOpen(false)}
              className="block hover:text-gray-400"
            >
              Update History
            </Link>
          </li>
        </div>
      </menu>
    </nav>
  );
};

export default Navbar;
