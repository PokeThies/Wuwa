import React from "react";
import Wuwa_logo from "/imgs/Wuwa_logo.png";

const Footer = () => {
  return (
    <footer className="footer bg-gradient-to-r from-zinc-950 via-gray-950 to-black text-gray-300 p-6">
      <div className="w-full max-w-7xl mx-auto flex flex-wrap justify-between items-start gap-4">
        {/* Left Section with Logo and Copyright */}
        <div className="flex flex-col items-center sm:flex-row sm:items-center sm:justify-start w-full sm:w-auto mb-6 sm:mb-0">
          <a href="/" className="flex-shrink-0">
            <img
              src={Wuwa_logo}
              alt="Wuwa Logo"
              className="w-36 sm:w-44 sm:h-20 lg:h-24"
            />
          </a>
          <p className="text-sm sm:text-base lg:text-lg mt-2 sm:mt-0 sm:ml-3 text-center sm:text-left">
            Copyright © {new Date().getFullYear()} - All rights reserved.
          </p>
        </div>

        {/* About Us Section */}
        <div className="flex flex-col text-sm sm:text-base space-y-2 sm:space-y-3 text-center sm:text-left w-full sm:w-auto sm:ml-2">
          <h3 className="text-lg font-semibold text-gray-200">About Us</h3>
          <a
            href="/Contact"
            className="hover:text-blue-400 transition-colors duration-300"
          >
            Contact
          </a>
          <a
            href="/Privacypolicy"
            className="hover:text-blue-400 transition-colors duration-300"
          >
            Privacy Policy
          </a>
          <a
            href="/Services"
            className="hover:text-blue-400 transition-colors duration-300"
          >
            Services
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
