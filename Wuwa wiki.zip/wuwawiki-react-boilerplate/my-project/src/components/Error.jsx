import React from 'react'

const Error = () => {
  return (
    <div>
      <h1>
        Failure Happend
      </h1>
    </div>
  )
}

export default Error
