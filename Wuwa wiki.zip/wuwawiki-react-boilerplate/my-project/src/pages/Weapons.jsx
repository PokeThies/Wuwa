import React from 'react'

const Weapons = () => {
  return (
    <div>
      
    </div>
  )
}

export default Weapons
