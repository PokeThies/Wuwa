import React from "react";
import { Link } from "react-router-dom";

const PageNotFound = () => {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-950 text-gray-800">
      <h1 className="text-4xl font-bold mb-4 text-red-500">Error 404</h1>
      <p className="text-lg mb-6 text-white">Oops! The page you're looking for doesn't exist.</p>
      <Link
        to="/"
        className="px-6 py-3 bg-red-600 text-white rounded-lg shadow-lg hover:bg-red-800 transition duration-200"
      >
        Back to Home
      </Link>
    </div>
  );
};

export default PageNotFound;
