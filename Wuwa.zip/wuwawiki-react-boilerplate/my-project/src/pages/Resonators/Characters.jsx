import React from 'react'

const Characters = () => {
  return (
    <div>
      
    </div>
  )
}

export default Characters
