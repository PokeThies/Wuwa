import React from 'react'

const Novaroutes = () => {
  return (
    <div>
      
    </div>
  )
}

export default Novaroutes
