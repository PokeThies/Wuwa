import React from 'react'

const Loader = () => {
  return (
    <div className="simple-spinner">
    <span></span>
  </div>
  )
}

export default Loader
